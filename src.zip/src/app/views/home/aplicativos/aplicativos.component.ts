import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aplicativos',
  templateUrl: './aplicativos.component.html',
  styleUrls: ['./aplicativos.component.css']
})
export class AplicativosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
