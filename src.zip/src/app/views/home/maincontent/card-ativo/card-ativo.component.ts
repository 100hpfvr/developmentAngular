import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-card-ativo",
  templateUrl: "./card-ativo.component.html",
  styleUrls: ["./card-ativo.component.css"],
})
export class CardAtivoComponent implements OnInit {
  constructor() {}

  estado = "Ativo";

  ngOnInit(): void {}

  /**
   * name
   */
  public mudaEstado(estado: "Ativo") {
    if (estado == "Ativo") {
      this.estado = "Inativo";
      return this.estado;
    } else {
      this.estado = "Ativo";
      return this.estado;
    }
  }
}
