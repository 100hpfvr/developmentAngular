import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-inativo',
  templateUrl: './card-inativo.component.html',
  styleUrls: ['./card-inativo.component.css']
})
export class CardInativoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
