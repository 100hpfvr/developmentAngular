import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usuarios-tela',
  templateUrl: './usuarios-tela.component.html',
  styleUrls: ['./usuarios-tela.component.css']
})
export class UsuariosTelaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
